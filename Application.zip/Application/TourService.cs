﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class TourService
    {
        private readonly IRepository<Tour> _tourRepository;

        public TourService(IRepository<Tour> tourRepository)
        {
            _tourRepository = tourRepository;
        }

        public async Task Add(Tour entity)
        {
           await _tourRepository.Add(entity);
        }

        public async Task Add(string columnNames, Tour entity, string tableName)
        {

            await _tourRepository.Add(columnNames, entity, tableName);
        }

        public async Task<List<Tour>> GetAll()
        {
            return await _tourRepository.GetAll<Tour>();
        }

        public async Task<List<Tour>> GetAll(string parameterName, string parameterValue)
        {
            return await _tourRepository.GetAll<Tour>(parameterName, parameterValue);
        }

        public async Task<List<Tour>> GetAll(string columnNames, string tableName, string parameterName, string parameterValue)
        {

            return await _tourRepository.GetAll<Tour>(columnNames, tableName, parameterName, parameterValue);

        }

        public async Task<Tour> GetAll(string columnNames, string tableName, string parameterName, string parameterValue, Tour entity)
        {
            // Implement custom logic if needed.
            return await _tourRepository.GetAll(columnNames, tableName, parameterName, parameterValue, new Tour());

        }

        public async Task DeleteByPrimaryKey(List<Tuple<string, string>> comparisonColumns, string tableName)
        {
            // Implement custom logic if needed.
            await _tourRepository.DeleteByPrimaryKey(comparisonColumns, tableName);
        }

        public async Task DeleteById(int id, string tableName)
        {
           await _tourRepository.DeleteById(id, tableName);
        }

        public async Task DeleteById(string title, string titleValue, string tableName)
        {
            await _tourRepository.DeleteById(title, titleValue, tableName);
        }

        public async Task<Tour> FindByAttribute(string columnNames, string comparisonColumns, string tableName, Tour entity)
        {

            return await _tourRepository.FindByAttribute(columnNames, comparisonColumns, tableName, entity);
        }

        public async Task<Tour> FindById(int id)
        {
            return await _tourRepository.FindById<Tour>(id);
        }

        public async Task<Tour> FindByName(List<Tuple<string, string>> comparisonColumns, Tour entity)
        {
            // Implement custom logic if needed.
            return await _tourRepository.FindByName(comparisonColumns, entity);
        }

        public async Task Update(Tour entity)
        {
            await _tourRepository.Update(entity);
        }

        public async Task Update(string columnNames, Tour entity, string compName, string compValue, string tableName)
        {
            await _tourRepository.Update(columnNames,entity, compName, compValue, tableName);
        }
    }
}

