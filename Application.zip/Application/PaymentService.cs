﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public  class PaymentDetailsService
    {
        private readonly IRepository<PaymentDetails>  _PaymentDetailsRepository;

        public  PaymentDetailsService(IRepository<PaymentDetails> PaymentDetailsRepository)
        {
             _PaymentDetailsRepository = PaymentDetailsRepository;
        }

        public async Task  Add(PaymentDetails entity)
        {
            await _PaymentDetailsRepository.Add(entity);
        }

        public async Task Add(string columnNames, PaymentDetails entity, string tableName)
        {

            await _PaymentDetailsRepository.Add(columnNames, entity, tableName);
        }

        public async Task<List<PaymentDetails>> GetAll()
        {
            return await _PaymentDetailsRepository.GetAll<PaymentDetails>();
        }

        public async Task<List<PaymentDetails>> GetAll(string parameterName, string parameterValue)
        {
            return await _PaymentDetailsRepository.GetAll<PaymentDetails>(parameterName, parameterValue);
        }

        public async Task<List<PaymentDetails>> GetAll(string columnNames, string tableName, string parameterName, string parameterValue)
        {

            return await _PaymentDetailsRepository.GetAll<PaymentDetails>(columnNames, tableName, parameterName, parameterValue);

        }

        public async Task<PaymentDetails> GetAll(string columnNames, string tableName, string parameterName, string parameterValue, PaymentDetails entity)
        {
            // Implement custom logic if needed.
            return await _PaymentDetailsRepository.GetAll(columnNames, tableName, parameterName, parameterValue, new PaymentDetails());

        }

        public async Task    DeleteByPrimaryKey(List<Tuple<string, string>> comparisonColumns, string tableName)
        {
            // Implement custom logic if needed.
            await _PaymentDetailsRepository.DeleteByPrimaryKey(comparisonColumns, tableName);
        }

        public async Task    DeleteById(int id, string tableName)
        {
            await _PaymentDetailsRepository.DeleteById(id, tableName);
        }

        public async Task    DeleteById(string title, string titleValue, string tableName)
        {
            await _PaymentDetailsRepository.DeleteById(title, titleValue, tableName);
        }

        public async Task<PaymentDetails> FindByAttribute(string columnNames, string comparisonColumns, string tableName, PaymentDetails entity)
        {

            return await _PaymentDetailsRepository.FindByAttribute(columnNames, comparisonColumns, tableName, entity);
        }

        public async Task<PaymentDetails> FindById(int id)
        {
            return await _PaymentDetailsRepository.FindById<PaymentDetails>(id);
        }

        public async Task<PaymentDetails> FindByName(List<Tuple<string, string>> comparisonColumns, PaymentDetails entity)
        {
            // Implement custom logic if needed.
            return await _PaymentDetailsRepository.FindByName(comparisonColumns, entity);
        }

        public async Task Update(PaymentDetails entity)
        {
            await _PaymentDetailsRepository.Update(entity);
        }

        public async Task Update(string columnNames, PaymentDetails entity, string compName, string compValue, string tableName)
        {
            await _PaymentDetailsRepository.Update(columnNames, entity, compName, compValue, tableName);
        }
    }
}

