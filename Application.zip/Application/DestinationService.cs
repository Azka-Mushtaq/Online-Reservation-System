﻿using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Application
{
    public class DestinationService
    {
        private readonly IRepository<Destination> _DestinationRepository;

        public  DestinationService(IRepository<Destination> DestinationRepository)
        {
            _DestinationRepository = DestinationRepository;
        }

        public async Task Add(Destination entity)
        {
            await _DestinationRepository.Add(entity);
        }

        public async Task Add(string columnNames, Destination entity, string tableName)
        {

            await _DestinationRepository.Add(columnNames, entity, tableName);
        }

        public async Task<List<Destination>> GetAll()
        {
            return await _DestinationRepository.GetAll<Destination>();
        }

        public async Task<List<Destination>> GetAll(string parameterName, string parameterValue)
        {
            return await _DestinationRepository.GetAll<Destination>(parameterName, parameterValue);
        }

        public async Task<List<Destination>> GetAll(string columnNames, string tableName, string parameterName, string parameterValue)
        {

            return await _DestinationRepository.GetAll<Destination>(columnNames, tableName, parameterName, parameterValue);

        }

        public async Task<Destination> GetAll(string columnNames, string tableName, string parameterName, string parameterValue, Destination entity)
        {
            // Implement custom logic if needed.
            return await _DestinationRepository.GetAll(columnNames, tableName, parameterName, parameterValue, new Destination());

        }

        public async Task DeleteByPrimaryKey(List<Tuple<string, string>> comparisonColumns, string tableName)
        {
            // Implement custom logic if needed.
           await _DestinationRepository.DeleteByPrimaryKey(comparisonColumns, tableName);
        }

        public async Task DeleteById(int id, string tableName)
        {
            await _DestinationRepository.DeleteById(id, tableName);
        }

        public async Task DeleteById(string title, string titleValue, string tableName)
        {
            _DestinationRepository.DeleteById(title, titleValue, tableName);
        }

        public async Task<Destination> FindByAttribute(string columnNames, string comparisonColumns, string tableName, Destination entity)
        {

            return await _DestinationRepository.FindByAttribute(columnNames, comparisonColumns, tableName, entity);
        }

        public async Task<Destination> FindById(int id)
        {
            return await _DestinationRepository.FindById<Destination>(id);
        }

        public async Task<Destination> FindByName(List<Tuple<string, string>> comparisonColumns,Destination entity)
        {
            // Implement custom logic if needed.
            return await _DestinationRepository.FindByName(comparisonColumns,entity);
        }

        public async Task Update(Destination entity)
        {
           await _DestinationRepository.Update(entity);
        }

        public  async Task Update(string columnNames, Destination entity, string compName, string compValue, string tableName)
        {
            await _DestinationRepository.Update(columnNames, entity, compName, compValue, tableName);
        }
    }
}

