﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Application
{
    public class BookingService
    {
        private readonly IRepository<Booking>  _BookingRepository;

        public  BookingService(IRepository<Booking> BookingRepository)
        {
             _BookingRepository = BookingRepository;
        }

        public async Task  Add(Booking entity)
        {
            await _BookingRepository.Add(entity);
        }

        public async Task  Add(string columnNames, Booking entity, string tableName)
        {

            await _BookingRepository.Add(columnNames, entity, tableName);
        }

        public async Task< List<Booking>> GetAll()
        {
            return await _BookingRepository.GetAll<Booking>();
        }

        public async Task< List<Booking>> GetAll(string parameterName, string parameterValue)
        {
            return await _BookingRepository.GetAll<Booking>(parameterName, parameterValue);
        }

        public async Task< List<Booking>> GetAll(string columnNames, string tableName, string parameterName, string parameterValue)
        {

            return await _BookingRepository.GetAll<Booking>(columnNames, tableName, parameterName, parameterValue);

        }

        public async Task< Booking> GetAll(string columnNames, string tableName, string parameterName, string parameterValue, Booking entity)
        {
            // Implement custom logic if needed.
            return await _BookingRepository.GetAll(columnNames, tableName, parameterName, parameterValue, new Booking());

        }

        public async Task   DeleteByPrimaryKey(List<Tuple<string, string>> comparisonColumns, string tableName)
        {
            // Implement custom logic if needed.
            await _BookingRepository.DeleteByPrimaryKey(comparisonColumns, tableName);
        }

        public async Task   DeleteById(int id, string tableName)
        {
            await _BookingRepository.DeleteById(id, tableName);
        }

        public async Task   DeleteById(string title, string titleValue, string tableName)
        {
            await _BookingRepository.DeleteById(title, titleValue, tableName);
        }

        public async Task< Booking> FindByAttribute(string columnNames, string comparisonColumns, string tableName, Booking entity)
        {

            return await _BookingRepository.FindByAttribute(columnNames, comparisonColumns, tableName, entity);
        }

        public async Task< Booking> FindById(int id)
        {
            return await _BookingRepository.FindById<Booking>(id);
        }

        public async Task< Booking> FindByName(List<Tuple<string, string>> comparisonColumns, Booking entity)
        {
            // Implement custom logic if needed.
            return await _BookingRepository.FindByName(comparisonColumns, entity);
        }

        public async Task  Update(Booking entity)
        {
            await _BookingRepository.Update(entity);
        }

        public async Task Update(string columnNames, Booking entity, string compName, string compValue, string tableName)
        {
            await _BookingRepository.Update(columnNames, entity, compName, compValue, tableName);
        }
    }
}

