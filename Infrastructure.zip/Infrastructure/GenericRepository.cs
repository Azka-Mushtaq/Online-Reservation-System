﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;

using Domain;
using System.Diagnostics;

namespace Infrastructure
{
    public class GenericRepository<TEntity> : IRepository<TEntity>
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
  
   
        public GenericRepository() { }

        public async Task Add(TEntity entity)
        {
            try
            {

                var tableName = typeof(TEntity).Name;
                var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ID" && p.Name != "File");

                var ColumnName = string.Join(",", properties.Select(x => x.Name));
                var parameterNames = string.Join(",", properties.Select(y => "@" + y.Name));

                string query = $"insert into {tableName} ({ColumnName}) values({parameterNames})";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in properties)
                    {
                        cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                    }

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("Your Details already exist", ex);
            }

        }

        public async Task Add(string columnNames, TEntity entity, string tableName)
        {
            try
            {
                var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ID" && p.Name != "File");

                var list = columnNames.Split(',');
                var parameterNames = string.Empty;
                for (int i = 0; i < list.Length; i++)
                {
                    if (i == list.Length - 1)
                        parameterNames += ("@" + list[i]);
                    else
                        parameterNames += ("@" + list[i] + ",");
                }

                string query = $"insert into {tableName} ({columnNames}) values({parameterNames})";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in properties)
                    {
                        if (list.Contains(property.Name))
                        {
                            cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                        }
                    }

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("Your Details already exist", ex);
            }

        }

        public async Task<List<TEntity>> GetAll<TEntity>() where TEntity : new()
        {

            try
            {
                string tableName = typeof(TEntity).Name;

                string query = $"SELECT * FROM {tableName}";

                List<TEntity> list = new List<TEntity>();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader dr = cmd.ExecuteReader();


                    while (dr.Read())
                    {
                        TEntity entity = new TEntity();
                        foreach (var property in typeof(TEntity).GetProperties())
                        {
                            if (property.Name != "File")
                                property.SetValue(entity, dr[property.Name]);
                        }
                        list.Add(entity);
                    }
                }
                return list;

            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }

        public async Task<List<TEntity>> GetAll<TEntity>(string parameterName, string parameterValue) where TEntity : new()
        {
            try
            {
                string tableName = typeof(TEntity).Name;

                string query = $"SELECT * FROM {tableName} where {parameterName} = @parameterVaue";

                List<TEntity> list = new List<TEntity>();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("parameterVaue", parameterValue);
                    SqlDataReader dr =  cmd.ExecuteReader();


                    while (dr.Read())
                    {
                        TEntity entity = new TEntity();
                        foreach (var property in typeof(TEntity).GetProperties())
                        {
                            if (property.Name != "File")
                                property.SetValue(entity, dr[property.Name]);
                        }
                        list.Add(entity);
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }

        public async Task<List<TEntity>> GetAll<TEntity>(string columnNames, string tableName, string parameterName, string parameterValue) where TEntity : new()
        {
            try
            {
                string query = $"SELECT * FROM {tableName} where {parameterName} = @parameterVaue";

                List<TEntity> list = new List<TEntity>();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("parameterVaue", parameterValue);
                    SqlDataReader dr = cmd.ExecuteReader();

                    var cn = columnNames.Split(',');

                    while (dr.Read())
                    {
                        TEntity entity = new TEntity();
                        foreach (var property in typeof(TEntity).GetProperties())
                        {
                            if (cn.Contains(property.Name))
                                property.SetValue(entity, dr[property.Name]);
                        }
                        list.Add(entity);
                    }
                }
                return list;

            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }


        public async Task<TEntity> GetAll(string columnNames, string tableName, string parameterName, string parameterValue, TEntity entity)
        {
            try
            {

                string query = $"SELECT * FROM {tableName} where {parameterName} = @parameterVaue";


                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("parameterVaue", parameterValue);
                    SqlDataReader dr = cmd.ExecuteReader();

                    var cn = columnNames.Split(',');

                    dr.Read();

                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (cn.Contains(property.Name))
                            property.SetValue(entity, dr[property.Name]);
                    }

                }
                return entity;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }
        public async Task DeleteByPrimaryKey(List<Tuple<string, string>> comparisonColumns, string tableName)
        {
            try
            {
                string whereCondition = string.Empty;


                for (int i = 0; i < comparisonColumns.Count; i++)
                {
                    if (i == comparisonColumns.Count - 1)
                        whereCondition += (comparisonColumns[i].Item1 + " = @" + comparisonColumns[i].Item1);
                    else
                        whereCondition += (comparisonColumns[i].Item1 + " = @" + comparisonColumns[i].Item1 + " and ");

                }
                string query = $"DELETE FROM {tableName} where {whereCondition}";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var tup in comparisonColumns)
                        cmd.Parameters.AddWithValue("@" + tup.Item1, tup.Item2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }

        public async Task DeleteById(int id, string tableName)
        {
            try
            {


                string query = $"DELETE FROM {tableName} where ID= @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@ID", id);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }
        public async Task DeleteById(string title, string titleValue, string tableName)
        {

            try
            {
                string whereCondition = string.Empty;


                string query = $"DELETE FROM {tableName} where {title}= @titleValue";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@titleValue", titleValue);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }
        public async  Task<TEntity> FindByAttribute(string columnNames, string comparisonColumns, string tableName, TEntity entity)
        {
            try
            {

                string whereCondition = string.Empty;
                var cols = comparisonColumns.Split(",");

                for (int i = 0; i < cols.Length; i++)
                {
                    if (i == cols.Length - 1)
                        whereCondition += (cols[i] + " = @" + cols[i]);
                    else
                        whereCondition += (cols[i] + " = @" + cols[i] + " and ");

                }
                string query = $"SELECT * FROM {tableName} where {whereCondition}";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (cols.Contains(property.Name))
                        {
                            cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                        }
                    }

                    SqlDataReader dr = cmd.ExecuteReader();


                    dr.Read();

                    var list = columnNames.Split(",");

                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (list.Contains(property.Name))
                            property.SetValue(entity, dr[property.Name]);
                    }

                }

                return entity;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }

        public async Task<TEntity> FindByName(List<Tuple<string, string>> comparisonColumns,TEntity entity)
        {
            try
            {

                string whereCondition = string.Empty;

                string destniatonName = "";
                for (int i = 0; i < comparisonColumns.Count; i++)
                {
                    destniatonName = comparisonColumns[i].Item2;
                    if (i == comparisonColumns.Count - 1)
                        whereCondition += (comparisonColumns[i].Item1 + " = @" + comparisonColumns[i].Item1);
                    else
                        whereCondition += (comparisonColumns[i].Item1 + " = @" + comparisonColumns[i].Item1 + " and ");

                }

                string tableName = typeof(TEntity).Name;
                string query = $"SELECT * FROM {tableName} where {whereCondition}";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (property.Name == "DestinationName")
                        {
                            cmd.Parameters.AddWithValue("@" + property.Name, destniatonName);
                        }
                    }

                    SqlDataReader dr = cmd.ExecuteReader();


                    dr.Read();


                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (property.Name != "File")
                            property.SetValue(entity, dr[property.Name]);
                    }

                }

                return entity;
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }

        }

        public async Task<TEntity> FindById<TEntity>(int id) where TEntity : new()
        {
            TEntity entity = new TEntity();

            try
            {
                string tableName = typeof(TEntity).Name;

                string query = $"SELECT * FROM {tableName} where ID = @ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("ID", id);

                    SqlDataReader dr = cmd.ExecuteReader();


                    dr.Read();


                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (property.Name != "File")
                            property.SetValue(entity, dr[property.Name]);
                    }

                }
                return entity; ;

            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
            return entity;
        }

        public async Task Update(TEntity entity)
        {
            try
            {
                string tableName = typeof(TEntity).Name;
                var properties = typeof(TEntity).GetProperties().Where(p => p.Name != "ID" && p.Name != "File");

                var values = string.Join(",", properties.Select(y => y.Name + " = @" + y.Name));

                string query = $"update {tableName} set {values} where ID= @ID";


                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in properties)
                    {
                        cmd.Parameters.AddWithValue(property.Name, property.GetValue(entity));
                    }

                    var idProperty = typeof(TEntity).GetProperty("ID");
                    cmd.Parameters.AddWithValue("ID", idProperty.GetValue(entity));

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("No Data Found", ex);
            }
        }

        public async Task Update(string columnNames, TEntity entity, string compName, string compValue, string tableName)
        {
            try
            {

                var list = columnNames.Split(',');
                var parameterNames = string.Empty;
                for (int i = 0; i < list.Length; i++)
                {
                    if (i == list.Length - 1)
                        parameterNames += (list[i] + " = " + "@" + list[i]);
                    else
                        parameterNames += (list[i] + " = " + "@" + list[i] + " , ");
                }

                string query = $"update {tableName} set {parameterNames} where {compName}= @{compName}";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    foreach (var property in typeof(TEntity).GetProperties())
                    {
                        if (list.Contains(property.Name))
                        {
                            cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(entity));
                        }
                    }
                    cmd.Parameters.AddWithValue("@" + compName, compValue);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine($"Trace: Exception type: {ex.GetType}, Message: {ex.Message}");
                Debug.WriteLine($"Debug: Exception type: {ex.GetType}, Message: {ex.Message}");
                throw new Exception("Your Details already exist", ex);
            }

        }

    }
}


