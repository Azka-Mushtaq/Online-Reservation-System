﻿using Microsoft.AspNetCore.Identity;

namespace Domain
{
    public class User: Microsoft.AspNet.Identity.EntityFramework.IdentityUser
    {
        public string Role {  get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
    }
}
