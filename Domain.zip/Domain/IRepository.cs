﻿using System.Collections.Generic;

namespace Domain
{
    public interface IRepository<TEntity>
    {
   
        public Task Add(TEntity entity);
        public Task Add(string columnNames, TEntity entity, string tableName);
        public Task<List<TEntity>> GetAll<TEntity>() where TEntity : new();

        public Task<List<TEntity>> GetAll<TEntity>(string parameterName, string parameterValue) where TEntity : new();
        public Task<List<TEntity>> GetAll<TEntity>(string columnNames, string tableName, string parameterName, string parameterValue) where TEntity : new();

        public Task<TEntity> GetAll(string columnNames, string tableName, string parameterName, string parameterValue, TEntity entity);
        public Task DeleteByPrimaryKey(List<Tuple<string, string>> comparisonColumns, string tableName);

        public Task DeleteById(int id, string tableName);
        public Task DeleteById(string title, string titleValue, string tableName);
        public Task<TEntity> FindByAttribute(string columnNames, string comparisonColumns, string tableName, TEntity entity);
        public Task<TEntity> FindById<TEntity>(int id) where TEntity : new();
        public Task<TEntity> FindByName(List<Tuple<string, string>> comparisonColumns, TEntity entity);
        public Task Update(TEntity entity);

        public Task Update(string columnNames, TEntity entity, string compName, string compValue, string tableName);

    }
}
