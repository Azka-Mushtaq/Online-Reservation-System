﻿namespace Domain
{
    public class PaymentDetails
    {
        public string? UserId { get; set; }
        public string? IBN { get; set; }
        public string? CVV { get; set; }
        public string? PaymentMethod { get; set; }
        public string? ExpiryDate { get; set; }
    }
}
