﻿using Microsoft.AspNetCore.SignalR;

namespace Online_Reservation_System.Models
{
    public class ChatHub:Hub
    {
        public async Task SendMessage(string productName, int quantity, string category)
        {
            await Clients.All.SendAsync("ReceiveProductNotification", productName, quantity, category);
        }

    }
}
