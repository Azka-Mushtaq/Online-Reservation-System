﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
namespace Online_Reservation_System.Models
{
    public class Destination
    {
        [ValidateNever]
        public int ID { get; set; }
        [Required(ErrorMessage ="Please Enter Destination Name")]
        [StringLength(50)]
        public string DestinationName { get; set; }

        [Required(ErrorMessage = "Please select destination type")]

        
        public string DestinationType { get; set; }

        [Required(ErrorMessage = "Please Enter Image")]
        public IFormFile File { get; set; }

        [Required]
       
        public string URL { get; set; }

    }


}
