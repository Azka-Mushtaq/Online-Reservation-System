﻿namespace Online_Reservation_System.Models
{
    public class Booking
    {
        public int? ID { get; set; }
        public string? UserID {  get; set; }
        public string? Members { get; set; }
        public string? Date { get; set; }
        
    }
}
