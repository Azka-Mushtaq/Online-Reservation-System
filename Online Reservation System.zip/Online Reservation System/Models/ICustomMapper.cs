﻿namespace Online_Reservation_System.Models
{
    public interface ICustomMapper<TDomain, TWeb>
    {
        public Task<TDomain> WebToDomain(TWeb webEntity);
        public Task<TWeb> DomainToWeb(TDomain domainEntity);
        public Task<List<TWeb>> GetAll(List<TDomain> domainList);
    }
}