﻿using System.ComponentModel.DataAnnotations;

namespace Online_Reservation_System.Models
{
    public class ValidDestinationType: ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            string val = value.ToString();
            if (val == "TOP DESTINATION" || val == "WARM DESTINATION" || val == "TOP ATTRACTIONS")
                return ValidationResult.Success;
            return ValidationResult.Success;
        }

    }
}
