using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Online_Reservation_System.Data;
using Online_Reservation_System.Models;
using Infrastructure;
using Domain;
using Application;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<Online_Reservation_System.Models.User>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>();
builder.Services.AddControllersWithViews();

//dependecy injection
builder.Services.AddScoped<IRepository<Domain.Destination>, GenericRepository<Domain.Destination>>();
builder.Services.AddScoped<IRepository<Domain.Tour>, GenericRepository<Domain.Tour>>();
builder.Services.AddScoped<IRepository<Domain.Booking>, GenericRepository<Domain.Booking>>();
builder.Services.AddScoped<IRepository<Domain.PaymentDetails>, GenericRepository<Domain.PaymentDetails>>();

//CustomMapper services 
builder.Services.AddScoped<ICustomMapper<Domain.Destination,Online_Reservation_System.Models.Destination>, CustomMapper<Domain.Destination,Online_Reservation_System.Models.Destination>> ();
builder.Services.AddScoped<ICustomMapper<Domain.Tour,Online_Reservation_System.Models.Tour>, CustomMapper<Domain.Tour,Online_Reservation_System.Models.Tour>> ();
builder.Services.AddScoped<ICustomMapper<Domain.Booking,Online_Reservation_System.Models.Booking>, CustomMapper<Domain.Booking,Online_Reservation_System.Models.Booking>> ();
builder.Services.AddScoped<ICustomMapper<Domain.PaymentDetails,Online_Reservation_System.Models.PaymentDetails>, CustomMapper<Domain.PaymentDetails,Online_Reservation_System.Models.PaymentDetails>> ();

//Aplication layer depenecies
builder.Services.AddScoped<DestinationService>();
builder.Services.AddScoped<TourService>();
builder.Services.AddScoped<BookingService>();
builder.Services.AddScoped<PaymentDetailsService>();

//Caching
builder.Services.AddMemoryCache();

builder.Services.AddAuthorization(options => {

    options.AddPolicy("AdminOnly", policy =>
     policy.RequireClaim("Role", "Admin"
));
});


//
builder.Services.AddSignalR();
//endpoints.MapHub<ChatHub>("/notificationHub");

var app = builder.Build();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

//app.MapControllerRoute(
//    name: "default",
//    pattern: "{controller=Home}/{action=Index}/{id?}");

// Register routes directly

// Register SignalR Hubs


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "name",
    pattern: "{controller=Home}/{action=Index}/{name?}");

app.MapControllerRoute(
    name: "title",
    pattern: "{controller=Home}/{action=Index}/{title?}");


app.MapRazorPages();
app.MapHub<ChatHub>("/notificationHub");


app.Run();
