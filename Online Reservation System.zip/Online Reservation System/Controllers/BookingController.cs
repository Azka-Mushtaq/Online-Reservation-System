﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using Online_Reservation_System.Models;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System.Security.Claims;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authorization;
using Domain;
using Application;
namespace Online_Reservation_System.Controllers
{
    [Authorize]
    public class BookingController : Controller
    {
        private BookingService _bookingRepository;
        private readonly UserManager<Online_Reservation_System.Models.User> _userManager;
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
        private readonly ICustomMapper<Domain.Booking, Online_Reservation_System.Models.Booking> _bookingMapper;
        private readonly ICustomMapper<Domain.PaymentDetails, Online_Reservation_System.Models.PaymentDetails> _paymentDetailsMapper;
        private PaymentDetailsService _paymentRepository;
        private string getUserId()
        {
            var claimsIdentity = (ClaimsIdentity)User.Identity;
            string userId = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            return userId;
        }


        public BookingController(UserManager<Online_Reservation_System.Models.User> userManager, BookingService bookingRepository
            , PaymentDetailsService paymentRepository,
            ICustomMapper<Domain.Booking, Online_Reservation_System.Models.Booking> mapper
            , ICustomMapper<Domain.PaymentDetails, Online_Reservation_System.Models.PaymentDetails> paymentDetailsMapper)
        {
            _userManager = userManager;
            _bookingRepository = bookingRepository;
            _bookingMapper = mapper;
            _paymentDetailsMapper = paymentDetailsMapper;
            _paymentRepository = paymentRepository;
        }
        [HttpGet]
        public IActionResult BookingForm(int id)
        {
            TourRepository truRepository = new TourRepository();
            Online_Reservation_System.Models.Tour tour = truRepository.find(id);

            TempData["Tour"] = JsonConvert.SerializeObject(tour);
            TempData.Keep("Tour");

            return View();
        }


        [HttpPost]
        public IActionResult BookingForm(Online_Reservation_System.Models.Booking booking)
        {

            string userId = getUserId();
            if (userId != null)
                booking.UserID = userId;

            if (ModelState.IsValid)
            {

                TempData["Booking"] = JsonConvert.SerializeObject(booking);
                TempData.Keep("Booking");
                return RedirectToAction("PaymentForm");
            }
            return View();
        }
        [HttpGet]
        public IActionResult PaymentForm()
        {
            return View();
        }
        [HttpPost]
        public IActionResult PaymentForm(Online_Reservation_System.Models.PaymentDetails payment)
        {

            string userId = getUserId();
            if (userId != null)
                payment.UserId = userId;

            if (ModelState.IsValid)
            {
                TempData["Payment"] = JsonConvert.SerializeObject(payment);
                TempData.Keep("Payment");

                return RedirectToAction("ConfirmBooking");
            }
            return View();
        }

        [HttpGet]
        public IActionResult BookingDetails()
        {
            return View();
        }

        [HttpGet]
        public IActionResult BookingConfirmed()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ConfirmBooking()
        {
            try
            {
                string paymentJson = TempData["Payment"].ToString();
                Online_Reservation_System.Models.PaymentDetails payment = JsonConvert.DeserializeObject<Online_Reservation_System.Models.PaymentDetails>(paymentJson);

                //GenericRepository<PaymentDetails> p = new GenericRepository<PaymentDetails>(connectionString);
                //p.Add(payment);
                await _paymentRepository.Add(await _paymentDetailsMapper.WebToDomain( payment));

                string bookingJson = TempData["Booking"].ToString();
                Online_Reservation_System.Models.Booking booking = JsonConvert.DeserializeObject<Online_Reservation_System.Models.Booking>(bookingJson);

                //GenericRepository<Booking> b = new GenericRepository<Booking>(connectionString);
                //b.Add(booking);
                await _bookingRepository.Add(await _bookingMapper.WebToDomain(booking));
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                return RedirectToAction("DisplayException");
            }
            return RedirectToAction("BookingDetails");
        }

        [HttpGet]
        public IActionResult DisplayException()
        {
            return View(TempData["ErrorMessage"]);
        }


    }
}
