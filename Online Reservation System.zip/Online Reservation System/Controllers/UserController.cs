﻿using Microsoft.AspNetCore.Mvc;
using Online_Reservation_System.Models;

namespace Online_Reservation_System.Controllers
{

    public class UserController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult SignUp()
        {
            return View();
        }

    }
}
