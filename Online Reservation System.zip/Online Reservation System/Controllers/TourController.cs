﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Online_Reservation_System.Models;
using System.Reflection;
using Domain;
using Application;

namespace Online_Reservation_System.Controllers
{
    public class TourController : Controller
    {
        private readonly TourService _repository;
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
        private readonly ICustomMapper<Domain.Tour,Online_Reservation_System.Models.Tour> _mapper;
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env;

        public TourController(ILogger<HomeController> logger, IWebHostEnvironment env, TourService repository
            , ICustomMapper<Domain.Tour, Models.Tour> mapper)
        {
            _logger = logger;
            _env = env;
            _repository = repository;
            _mapper = mapper;
        }

        [Authorize (Policy = "AdminOnly")]
        public async Task<IActionResult> AddTour()
        {
            return View();
        }


        [Authorize(Policy = "AdminOnly")]
        [HttpPost]
        public async Task<IActionResult> AddTour(Online_Reservation_System.Models.Tour tour, IFormFile url)
        {
            string wwwrootpath = _env.WebRootPath;
            string path = Path.Combine(wwwrootpath, "UploadedImages/Tours");
            if (url != null && url.Length > 0)
            {
                string filepath = Path.Combine(path, url.FileName);
                tour.URL = Path.Combine("UploadedImages/Tours", url.FileName);
                using (var FileStream = new FileStream(filepath, FileMode.Create))
                {
                    url.CopyTo(FileStream);

                }
            }

            if (ModelState.IsValid)
            {

                //GenericRepository<Tour> tr = new GenericRepository<Tour>(connectionString);

                //Insert into Tour table
                string columnNames = "Title,DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                //tr.Add(columnNames, tour, "Tour");
                await _repository.Add(columnNames,await _mapper.WebToDomain(tour), "Tour");

                //Insert into Included Services
                columnNames = string.Empty;
                columnNames = "DestinationName,Title,IncludedServices";
                //tr.Add(columnNames, tour, "IncludedServices");
                await _repository.Add(columnNames,await _mapper.WebToDomain( tour), "IncludedServices");

                // Insert into Excluded Services
                columnNames = string.Empty;
                columnNames = "DestinationName,Title,ExcludedServices";
                //tr.Add(columnNames, tour, "ExcludedServices");
                await _repository.Add(columnNames,await _mapper.WebToDomain( tour), "ExcludedServices");

                // Insert into Key Features
                columnNames = string.Empty;
                columnNames = "DestinationName,Title,KeyFeatures";
                //tr.Add(columnNames, tour, "KeyFeatures");
                await _repository.Add(columnNames,await _mapper.WebToDomain( tour), "KeyFeatures");

                return View("ViewTour", tour);
            }
            else
                return View();

        }


        [Authorize(Policy = "AdminOnly")]
        public async Task<IActionResult> Edit(int id)
        {
            TourRepository tourRepository = new TourRepository();
            Online_Reservation_System.Models.Tour tour = tourRepository.find(id);
            TempData["id"] = id;
            TempData["Title"] = tour.Title;
            TempData["URL"] = tour.URL;
            return View("Edit", tour);
        }


        [Authorize(Policy = "AdminOnly")]
        [HttpPost]
        public async Task <IActionResult> Edit(Online_Reservation_System.Models.Tour tour)
        {
            tour.ID = Convert.ToInt32(TempData["id"].ToString());
            tour.URL= TempData["URL"].ToString();
            if (ModelState.IsValid)
            {
                string title = (TempData["Title"].ToString());
                //GenericRepository<Tour> tr = new GenericRepository<Tour>(connectionString);

                //Insert into Included Services
                string columnNames = string.Empty;
                columnNames = "DestinationName,IncludedServices";
                //tr.Update(columnNames, tour, "Title", title, "IncludedServices");
                await _repository.Update(columnNames,await _mapper.WebToDomain( tour), "Title", title, "IncludedServices");

                // Insert into Excluded Services
                columnNames = string.Empty;
                columnNames = "DestinationName,ExcludedServices";
                //tr.Update(columnNames, tour, "Title", title, "ExcludedServices");
                await _repository.Update(columnNames,await _mapper.WebToDomain( tour), "Title", title, "ExcludedServices");

                // Insert into Key Features
                columnNames = string.Empty;
                columnNames = "DestinationName,KeyFeatures";
                //tr.Update(columnNames, tour, "Title", title, "KeyFeatures");
                await _repository.Update(columnNames, await _mapper.WebToDomain( tour), "Title", title, "KeyFeatures");

                //update into Tour table
                columnNames = string.Empty;
                columnNames = "DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                //tr.Update(columnNames, tour, "Title", title, "Tour");
                await _repository.Update(columnNames, await _mapper.WebToDomain( tour), "Title", title, "Tour");


                return View("ViewTour", tour);
            }

            return View();
        }

        [Authorize(Policy = "AdminOnly")]
        public async Task<IActionResult> Delete(string title,string name)
        {
            //GenericRepository<Tour> genericRepository = new GenericRepository<Tour>(connectionString);

            //// Delete from child tables
            //genericRepository.DeleteById("Title", title, "KeyFeatures");
            //genericRepository.DeleteById("Title", title, "ExcludedServices");
            //genericRepository.DeleteById("Title", title, "IncludedServices");

            ////Delete From Tour Table (parent table)
            //genericRepository.DeleteById("Title", title, "Tour");

            // Delete from child tables
            await _repository.DeleteById("Title", title, "KeyFeatures");
            await _repository.DeleteById("Title", title, "ExcludedServices");
            await _repository.DeleteById("Title", title, "IncludedServices");

            //Delete From Tour Table (parent table)
            await _repository.DeleteById("Title", title, "Tour");

            return RedirectToAction("viewAll", new { name = name });

        }

        [Authorize]
        public async Task<IActionResult> viewAll(string name)
        {
            List<Online_Reservation_System.Models.Tour> list = new List<Online_Reservation_System.Models.Tour>();
            try
            {

                //GenericRepository<Tour> tr = new GenericRepository<Tour>(connectionString);

                //Tour table
                string columnNames = "ID,Title,DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                //list = tr.GetAll<Tour>(columnNames, "Tour", "destinationName", name);
                list =await _mapper.GetAll(await _repository.GetAll(columnNames, "Tour", "destinationName", name));

                for (int i = 0; i < list.Count; i++)
                {
                    //Included Services
                    columnNames = string.Empty;
                    columnNames = "IncludedServices";
                    //tr.GetAll(columnNames, "IncludedServices", "Title", list[i].Title, list[i]);
                    await _repository.GetAll(columnNames, "IncludedServices", "Title", list[i].Title, await _mapper.WebToDomain( list[i]));

                    //Excluded Services
                    columnNames = string.Empty;
                    columnNames = "ExcludedServices";
                    //tr.GetAll(columnNames, "ExcludedServices", "Title", list[i].Title, list[i]);
                    await _repository.GetAll(columnNames, "ExcludedServices", "Title", list[i].Title,await _mapper.WebToDomain( list[i]));

                    //key features
                    columnNames = string.Empty;
                    columnNames = "KeyFeatures";
                    //tr.GetAll(columnNames, "KeyFeatures", "Title", list[i].Title, list[i]);
                    await _repository.GetAll(columnNames, "KeyFeatures", "Title", list[i].Title,await _mapper.WebToDomain(list[i]));

                }
                TempData["DestinationName"] = name;
                return View(list);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                RedirectToAction("DisplayException", "Booking");
            }
            return View(list);
        }

        [Authorize]
        public async Task<IActionResult> Details(int id)
        {
            //GenericRepository<Tour> tourRepository = new GenericRepository<Tour>(connectionString);

            Online_Reservation_System.Models.Tour tour = new Online_Reservation_System.Models.Tour() { ID = id };

            string columnNames = "Title,DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
            string comparisonColumns = "ID";
            //tour = tourRepository.FindByAttribute(columnNames, comparisonColumns, "Tour", tour);
            tour =await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, comparisonColumns, "Tour",await _mapper.WebToDomain( tour)));

            //Included Services
            columnNames = string.Empty;
            comparisonColumns = string.Empty;
            columnNames = "IncludedServices";
            comparisonColumns = "DestinationName,Title";

            //tour = tourRepository.FindByAttribute(columnNames, comparisonColumns, "IncludedServices", tour);
            tour =await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, comparisonColumns, "IncludedServices",await _mapper.WebToDomain( tour)));

            //Excluded Services
            columnNames = string.Empty;
            columnNames = "ExcludedServices";
            //tour = tourRepository.FindByAttribute(columnNames, comparisonColumns, "ExcludedServices", tour);
            tour =await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, comparisonColumns, "ExcludedServices",await _mapper.WebToDomain( tour)));

            //key features
            columnNames = string.Empty;
            columnNames = "KeyFeatures";
            //tour = tourRepository.FindByAttribute(columnNames, comparisonColumns, "KeyFeatures", tour);
            tour =await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, comparisonColumns, "KeyFeatures",await _mapper.WebToDomain( tour)));

            return View("ViewTour", tour);
        }
    }
}
