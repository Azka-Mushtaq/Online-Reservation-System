﻿using Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Reservation_System.Models;
using System.Security.Policy;
using Application;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.SignalR;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace Online_Reservation_System.Controllers
{

    public class DestinationController : Controller
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
        private readonly IHubContext<ChatHub> _hubContext;
        //Mapping
        private readonly CustomMapper<Domain.Destination, Online_Reservation_System.Models.Destination> _mapper =
             new CustomMapper<Domain.Destination, Models.Destination>();
        private DestinationService _destinationRepository;

        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env;

        //In memory cache
        private readonly IMemoryCache _memoryCache;

        //Constructor injection
        public DestinationController(ILogger<HomeController> logger,
            IWebHostEnvironment env, DestinationService destinationRepository,
            IMemoryCache memoryCache,IHubContext<ChatHub> hubContext
            )
        {
            _memoryCache = memoryCache;
            _logger = logger;
            _env = env;
            _hubContext = hubContext;
            _destinationRepository = destinationRepository;
        }


        [Authorize(Policy = "AdminOnly")]
        [HttpGet]
        //Add Destination
        public IActionResult AddDestination(string name)
        {
            TempData["DestinationType"] = name;
            TempData.Keep("DestinationType");
            return View();
        }


        [Authorize(Policy = "AdminOnly")]
        [HttpPost]
        public async Task<IActionResult> AddDestination(Online_Reservation_System.Models.Destination destination)
        {


            string wwwrootpath = _env.WebRootPath;
            string path = Path.Combine(wwwrootpath, "UploadedImages/Destinations");
            if (destination.File != null && destination.File.Length > 0)
            {
                string filepath = Path.Combine(path, destination.File.FileName);
                destination.URL = Path.Combine("UploadedImages/Destinations", destination.File.FileName);
                using (var FileStream = new FileStream(filepath, FileMode.Create))
                {
                    destination.File.CopyTo(FileStream);

                }
            }
            // Manually set the state of the URL field to valid and check ModelState
            ModelState.Remove(nameof(destination.URL)); // Remove the old entry
            TryValidateModel(destination);


            if (ModelState.IsValid)
            {

                //GenericRepository<Destination> dt = new GenericRepository<Destination>(connectionString);
                //dt.Add(destination);

                await _destinationRepository.Add(await _mapper.WebToDomain(destination));

                await _hubContext.Clients.All.SendAsync("ReceiveProductNotification",
                    $"Hey all users!! A new Destination has been added Name={destination.DestinationName}", $"Destination Type ={destination}",
                    $"DestinationType={destination.DestinationType}");                // return /*Json(true);*/
                return RedirectToAction("Index", "Home");
            }
            else
                return View();
        }

        [Authorize(Policy = "AdminOnly")]
        [HttpGet]
        public async Task<IActionResult> GetById(int id)
        {
            //GenericRepository<Destination> genericRepository = new GenericRepository<Destination>(connectionString);
            TempData["id"] = id;
            Online_Reservation_System.Models.Destination destination = await _mapper.DomainToWeb(await _destinationRepository.FindById(id));

            string jsonString = JsonConvert.SerializeObject(destination);
            return Json(jsonString);
        }

        [HttpGet]
        public async Task<IActionResult> GetByName(string destinationName)
        {
            //GenericRepository<Destination> genericRepository = new GenericRepository<Destination>(connectionString);
            try
            {

                Online_Reservation_System.Models.Destination destination = new Online_Reservation_System.Models.Destination();
                List<Tuple<string, string>> comparison = new List<Tuple<string, string>>()
            {
                new Tuple<string,string>("DestinationName",$"{destinationName}")
            };
                destination =await _mapper.DomainToWeb(await _destinationRepository.FindByName(comparison,await _mapper.WebToDomain(destination)));
                if (destination == null) return Json(false);

                List<Online_Reservation_System.Models.Destination> data = new List<Models.Destination> { destination };
                return PartialView("_ShowTopDestinations", data);
               
            }
            catch
            {
                return Json(false);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetData(string destinationType = "", string destinationName = "")
        {

            List<Online_Reservation_System.Models.Destination> data = new List<Online_Reservation_System.Models.Destination>();
            try
            {
                if (destinationType != "")
                {
                    var cacheKey = destinationType;
                    if (!_memoryCache.TryGetValue(cacheKey, out data))
                    {
                        data = await _mapper.GetAll(await _destinationRepository.GetAll("DestinationType", destinationType));

                        var cacheEntryOptions = new MemoryCacheEntryOptions
                        {
                            AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(1)
                        };
                        _memoryCache.Set(cacheKey, data, cacheEntryOptions);

                    }

                    if (destinationType.Trim() == "TOP DESTINATION")
                        return PartialView("_ShowTopDestinations", data);
                    else if (destinationType.Trim() == "WARM DESTINATION")
                        return PartialView("_ShowWarmDestinations", data);
                    else
                        return PartialView("_ShowTopAttractions", data);
                }
                else
                {
                    data = await _mapper.GetAll(await _destinationRepository.GetAll("DestinationName", destinationName));
                    return PartialView("_SearchResults", data);
                }

            }
            catch
            {
                return Json(false);
            }
        }


        [Authorize(Policy = "AdminOnly")]
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            Online_Reservation_System.Models.Destination destination = await _mapper.DomainToWeb(await _destinationRepository.FindById(id));
            return View(destination);
        }
        [Authorize(Policy = "AdminOnly")]
        [HttpPost]

        public async Task<IActionResult> Edit(Online_Reservation_System.Models.Destination destination)
        {

            string wwwrootpath = _env.WebRootPath;
            string path = Path.Combine(wwwrootpath, "UploadedImages/Destinations");
            if (destination.File != null && destination.File.Length > 0)
            {
                string filepath = Path.Combine(path, destination.File.FileName);
                destination.URL = Path.Combine("UploadedImages/Destinations", destination.File.FileName);
                using (var FileStream = new FileStream(filepath, FileMode.Create))
                {
                    destination.File.CopyTo(FileStream);

                }
            }
            //destination.ID = Convert.ToInt32(TempData["id"].ToString());
            if (ModelState.IsValid)
            {
                //GenericRepository<Destination> genericRepository = new GenericRepository<Destination>(connectionString);
                //genericRepository.Update(destination);
                await _destinationRepository.Update(await _mapper.WebToDomain(destination));

                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        //public IActionResult Edit(int ID, string DestinationName, string DestinationType, IFormFile URL)
        //{
        //    Destination destination = new Destination()
        //    {
        //        ID = ID,
        //        DestinationName = DestinationName,
        //        DestinationType = DestinationType
        //    };
        //    string wwwrootpath = _env.WebRootPath;
        //    string path = Path.Combine(wwwrootpath, "UploadedImages/Destinations");
        //    if (URL != null && URL.Length > 0)
        //    {
        //        string filepath = Path.Combine(path, URL.FileName);
        //        destination.URL = Path.Combine("UploadedImages/Destinations", URL.FileName);
        //        using (var FileStream = new FileStream(filepath, FileMode.Create))
        //        {
        //            URL.CopyTo(FileStream);

        //        }
        //    }
        //    destination.ID = Convert.ToInt32(TempData["id"].ToString());
        //    if (ModelState.IsValid)
        //    {
        //        //GenericRepository<Destination> genericRepository = new GenericRepository<Destination>(connectionString);
        //        //genericRepository.Update(destination);
        //        _destinationRepository.Update(destination);
        //        return Json(true);
        //        return RedirectToAction("Index", "Home");
        //    }
        //    return Json(false);
        //    return View();
        //}

        [Authorize(Policy = "AdminOnly")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string name)
        {
            //Delete from Destinations
            //GenericRepository<Destination> gRepo = new GenericRepository<Destination>(connectionString);
            //gRepo.DeleteById("DestinationName", name,"Destination");
            try
            {
                await _destinationRepository.DeleteById("DestinationName", name, "Destination");

                return Json(true);
            }
            catch (Exception ex)
            {
                throw new Exception("Not Delete ");
            }

        }
    }
}
