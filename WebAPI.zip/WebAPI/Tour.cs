﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace WebAPI
{
    public class Tour
    {
        [ValidateNever]
        public int ID { get; set; }
        [Required(ErrorMessage = "Enter destination name")]
        public string DestinationName  { get; set; }

        [Required(ErrorMessage = "Enter tour title")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Enter description")]
        public string Description { get; set; }
        public string URL { get; set; } = "url";

        [Required(ErrorMessage = "Enter ranking")]
       
        public int Ranking { get; set; }

        [Required(ErrorMessage = "Enter cost")]
       
        public decimal Cost { get; set; }

        [Required(ErrorMessage = "Enter key features")]
        public string KeyFeatures { get; set; }

        [Required(ErrorMessage = "Enter included services")]
        public string IncludedServices { get; set; } 
        [Required(ErrorMessage = "Enter excluded services")]
        public string ExcludedServices { get; set; }

        
        //[Required(ErrorMessage = "Enter key features")]
        //public List<string> KeyFeatures { get; set; } = new List<string>();

        //[Required(ErrorMessage = "Enter included services")]
        //public List<string> ServicesIncluded { get; set; } = new List<string>();
        //[Required(ErrorMessage = "Enter excluded services")]
        //public List<string> ServicesExcluded { get; set; } = new List<string>();

        [Required(ErrorMessage = "Enter start date")]

        public DateTime StartTime { get; set; }

        [Required(ErrorMessage = "Enter end date ")]

        public DateTime EndTime { get; set; }

    }
}
