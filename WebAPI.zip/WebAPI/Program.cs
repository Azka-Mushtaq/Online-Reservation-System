using Domain;
using Infrastructure;
using Application;
using WebAPI;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//dependecy injection
builder.Services.AddScoped<IRepository<Domain.Destination>, GenericRepository<Domain.Destination>>();
builder.Services.AddScoped<IRepository<Domain.Tour>, GenericRepository<Domain.Tour>>();
builder.Services.AddScoped<IRepository<Domain.Booking>, GenericRepository<Domain.Booking>>();
builder.Services.AddScoped<IRepository<Domain.PaymentDetails>, GenericRepository<Domain.PaymentDetails>>();

//CustomMapper services 
builder.Services.AddScoped<ICustomMapper<Domain.Destination, WebAPI.Destination>, CustomMapper<Domain.Destination, WebAPI.Destination>>();
builder.Services.AddScoped<ICustomMapper<Domain.Tour, WebAPI.Tour>, CustomMapper<Domain.Tour, WebAPI.Tour>>();
builder.Services.AddScoped<ICustomMapper<Domain.Booking, WebAPI.Booking>, CustomMapper<Domain.Booking, WebAPI.Booking>>();
builder.Services.AddScoped<ICustomMapper<Domain.PaymentDetails, WebAPI.PaymentDetails>, CustomMapper<Domain.PaymentDetails, WebAPI.PaymentDetails>>();

//Aplication layer depenecies
builder.Services.AddScoped<DestinationService>();
builder.Services.AddScoped<TourService>();
builder.Services.AddScoped<BookingService>();
builder.Services.AddScoped<PaymentDetailsService>();

//Caching
builder.Services.AddMemoryCache();

builder.Services.AddAuthorization(options => {

    options.AddPolicy("AdminOnly", policy =>
     policy.RequireClaim("Role", "Admin"
));
});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
