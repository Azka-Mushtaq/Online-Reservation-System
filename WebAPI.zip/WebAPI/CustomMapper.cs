﻿using System.Reflection;

namespace WebAPI
{
    public class CustomMapper<TDomain, TWeb>:ICustomMapper<TDomain, TWeb>
    {
        public async Task<TDomain> WebToDomain(TWeb webEntity)
        {
            // Create a new instance of TWeb
            var domainEntity = Activator.CreateInstance<TDomain>();

            // Get properties of both types 
            var domainProperties = typeof(TDomain).GetProperties();
            var webProperties = typeof(TWeb).GetProperties();

            // Iterate over domain properties and map to web properties
            foreach (var domainProp in domainProperties)
            {
                // Find a matching property in the web type
                var webProp =typeof(TWeb).GetProperty(domainProp.Name);

                if (webProp != null)
                {
                    // Get the value from the domain entity and set it to the web entity
                    var value = webProp.GetValue(webEntity);
                    domainProp.SetValue(domainEntity, value);
                }
            }

            return domainEntity;

        }

        public async Task<TWeb> DomainToWeb(TDomain domainEntity)
        {
            // Create a new instance of TWeb
            var webEntity = Activator.CreateInstance<TWeb>();

            // Get properties of both types
            var domainProperties = typeof(TDomain).GetProperties();
            var webProperties = typeof(TWeb).GetProperties();

            // Iterate over domain properties and map to web properties
            foreach (var webProp in webProperties)
            {
                // Find a matching property in the web type
                var domainProp = typeof(TDomain).GetProperty(webProp.Name);

                if (domainProp != null)
                {
                    // Get the value from the domain entity and set it to the web entity
                    var value = domainProp.GetValue(domainEntity);
                    webProp.SetValue(webEntity, value);
                }
            }

            return webEntity;

        }
        public async  Task<List<TWeb>> GetAll(List<TDomain> domainList)
        {
            var webList = new List<TWeb>();

            foreach (TDomain domain in domainList)
            {
                TWeb web;
                if (domain != null)
                {
                    web = await DomainToWeb(domain);
                    webList.Add(web);
                }

            }

            return webList;

        }
    }
}
