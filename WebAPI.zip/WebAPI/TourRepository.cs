﻿using System.Collections.Generic;
using System.Data.SqlClient;


namespace WebAPI
{
    public class TourRepository
    {

        //Add
        private void AddTour(Tour tour)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //Insert into Tour
            string query = "insert into Tour(destinationName,title,description,ranking,cost,startTime,endTime,url) " +
                "values(@dn,@t,@d,@r,@c,@st,@et,@u)";
            SqlParameter dId = new SqlParameter("dn", tour.DestinationName);
            SqlParameter title = new SqlParameter("t", tour.Title);
            SqlParameter description = new SqlParameter("d", tour.Description);
            SqlParameter ranking = new SqlParameter("r", tour.Ranking);
            SqlParameter cost = new SqlParameter("c", tour.Cost);
            SqlParameter startTime = new SqlParameter("st", tour.StartTime);
            SqlParameter endTime = new SqlParameter("et", tour.EndTime);
            SqlParameter url = new SqlParameter("u", tour.URL);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(dId);
            cmd.Parameters.Add(title);
            cmd.Parameters.Add(description);
            cmd.Parameters.Add(ranking);
            cmd.Parameters.Add(cost);
            cmd.Parameters.Add(startTime);
            cmd.Parameters.Add(endTime);
            cmd.Parameters.Add(url);

            cmd.ExecuteNonQuery();
        }
        private void AddFeatures(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string feature in tour.KeyFeatures)
            //{
            // Store data in features table
            string query = "insert into KeyFeatures(title,destinationName,feature) values(@t,@dn,@f)";
            SqlParameter f1 = new SqlParameter("dn", tour.DestinationName);
            SqlParameter f2 = new SqlParameter("t", tour.Title);
            SqlParameter f3 = new SqlParameter("f", tour.KeyFeatures);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);
            cmd.Parameters.Add(f3);

            cmd.ExecuteNonQuery();

            //}
            connection.Close();

        }
        private void AddServicesIncluded(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string service in tour.ServicesIncluded)
            //{
            // Store data in features table
            string query = "insert into IncludedServices(title,destinationName,service) values(@t,@did,@s)";
            SqlParameter f1 = new SqlParameter("dId", tour.DestinationName);
            SqlParameter f2 = new SqlParameter("t", tour.Title);
            SqlParameter f3 = new SqlParameter("s", tour.IncludedServices);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);
            cmd.Parameters.Add(f3);

            cmd.ExecuteNonQuery();
            //}
            connection.Close();

        }
        private void AddServicesExcluded(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string service in tour.ServicesExcluded)
            //{
            // Store data in features table
            string query = "insert into ExcludedServices(title,destinationName,service) values(@t,@did,@s) ";
            SqlParameter f1 = new SqlParameter("t", tour.Title);
            SqlParameter f2 = new SqlParameter("did", tour.DestinationName);
            SqlParameter f3 = new SqlParameter("s", tour.ExcludedServices);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);
            cmd.Parameters.Add(f3);

            cmd.ExecuteNonQuery();

            // }
            connection.Close();

        }

        //Edit
        private void EditTour(Tour tour)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //Edit Tour
            string query = "UPDATE Tour SET destinationName = @dn, title = @t, description = @d, ranking = @r, cost = @c, startTime = @st, endTime = @et, url=@u WHERE Id = @id";
            SqlParameter dId = new SqlParameter("@dn", tour.DestinationName);
            SqlParameter title = new SqlParameter("@t", tour.Title);
            SqlParameter description = new SqlParameter("@d", tour.Description);
            SqlParameter ranking = new SqlParameter("@r", tour.Ranking);
            SqlParameter cost = new SqlParameter("@c", tour.Cost);
            SqlParameter startTime = new SqlParameter("@st", tour.StartTime);
            SqlParameter endTime = new SqlParameter("@et", tour.EndTime);
            SqlParameter url = new SqlParameter("@u", tour.URL);
            SqlParameter tourId = new SqlParameter("@id", tour.ID); // Assuming there's a property called TourId in your Tour class

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(dId);
            cmd.Parameters.Add(title);
            cmd.Parameters.Add(description);
            cmd.Parameters.Add(ranking);
            cmd.Parameters.Add(cost);
            cmd.Parameters.Add(startTime);
            cmd.Parameters.Add(endTime);
            cmd.Parameters.Add(tourId);
            cmd.Parameters.Add(url);

            cmd.ExecuteNonQuery();
        }
        private void EditFeatures(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string feature in tour.KeyFeatures)
            //{
            // Store data in features table
            string query = "UPDATE KeyFeatures SET feature = @f WHERE title = @t AND destinationName = @dn";
            SqlParameter f1 = new SqlParameter("@t", tour.Title);
            SqlParameter f2 = new SqlParameter("@dn", tour.DestinationName);
            SqlParameter f3 = new SqlParameter("@f", tour.KeyFeatures);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);
            cmd.Parameters.Add(f3);

            cmd.ExecuteNonQuery();

            //}
            connection.Close();

        }
        private void EditServicesIncluded(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string service in tour.ServicesIncluded)
            //{
            // Store data in features table
            string query = "UPDATE IncludedServices SET service = @s WHERE title = @t AND destinationName = @did";
            SqlParameter f1 = new SqlParameter("@t", tour.Title);
            SqlParameter f2 = new SqlParameter("@did", tour.DestinationName);
            SqlParameter f3 = new SqlParameter("@s", tour.IncludedServices);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);
            cmd.Parameters.Add(f3);

            cmd.ExecuteNonQuery();

            //}
            connection.Close();

        }
        private void EditServicesExcluded(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string service in tour.ServicesExcluded)
            //{
            // Store data in features table
            string query = "UPDATE ExcludedServices SET service = @s WHERE title = @t AND destinationName = @did";
            SqlParameter f1 = new SqlParameter("@t", tour.Title);
            SqlParameter f2 = new SqlParameter("@did", tour.DestinationName);
            SqlParameter f3 = new SqlParameter("@s", tour.ExcludedServices);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);
            cmd.Parameters.Add(f3);

            cmd.ExecuteNonQuery();


            // }
            connection.Close();

        }

        //Delete
        private void DeleteTour(int id)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //Edit Tour
            string query = "delete from Tour   WHERE Id = @id";
           
            SqlParameter tourId = new SqlParameter("@id", id); // Assuming there's a property called TourId in your Tour class

            SqlCommand cmd = new SqlCommand(query, connection);
          
            cmd.Parameters.Add(tourId);
            cmd.ExecuteNonQuery();
        }
        private void DeleteFeatures(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string feature in tour.KeyFeatures)
            //{
            // Store data in features table
            string query = "delete from KeyFeatures  WHERE title = @t AND destinationName = @dn";
            SqlParameter f1 = new SqlParameter("@t", tour.Title);
            SqlParameter f2 = new SqlParameter("@dn", tour.DestinationName);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);

            cmd.ExecuteNonQuery();

            //}
            connection.Close();

        }
        private void DeleteServicesIncluded(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string service in tour.ServicesIncluded)
            //{
            // Store data in features table
            string query = "delete from IncludedServices  WHERE title = @t AND destinationName = @did";
            SqlParameter f1 = new SqlParameter("@t", tour.Title);
            SqlParameter f2 = new SqlParameter("@did", tour.DestinationName);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);

            cmd.ExecuteNonQuery();

            //}
            connection.Close();

        }
        private void DeleteServicesExcluded(Tour tour)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //foreach (string service in tour.ServicesExcluded)
            //{
            // Store data in features table
            string query = "delete from ExcludedServices  WHERE title = @t AND destinationName = @did";
            SqlParameter f1 = new SqlParameter("@t", tour.Title);
            SqlParameter f2 = new SqlParameter("@did", tour.DestinationName);

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(f1);
            cmd.Parameters.Add(f2);

            cmd.ExecuteNonQuery();


            // }
            connection.Close();

        }

        //Public functions
        public void Add(Tour tour)
        {

            AddTour(tour);

            AddFeatures(tour);

            AddServicesIncluded(tour);
            AddServicesExcluded(tour);

        }

        //Delete
        public void Delete(int id)
        {
            Tour tour = find(id);
            DeleteServicesExcluded(tour);
            DeleteServicesIncluded(tour);
            DeleteFeatures(tour);
            DeleteTour(id);

        }
        public Tour find(int id)
        {
            Tour tr = new Tour();
            try
            {
                string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();



                // select tour details
                string selectQuery = "select * from tour where id = @t";
                SqlParameter ti = new SqlParameter("t", id);


                SqlCommand cmd = new SqlCommand(selectQuery, connection);
                cmd.Parameters.Add(ti);

                SqlDataReader tour = cmd.ExecuteReader();
                tour.Read();

                tr.DestinationName = Convert.ToString(tour[0]);
                tr.Title = Convert.ToString(tour[1]);
                tr.Description = Convert.ToString(tour[2]);
                tr.URL = Convert.ToString(tour[3]);
                tr.Ranking = Convert.ToInt32(tour[4]);
                tr.Cost = Convert.ToInt32(tour[5]);
                tr.StartTime = Convert.ToDateTime(tour[6]);
                tr.EndTime = Convert.ToDateTime(tour[7]);
                tour.Close();


                string selectFeatures = "select feature from keyFeatures f join tour t on f.destinationName = @dn and f.title = @t";
                SqlCommand fcmd = new SqlCommand(selectFeatures, connection);
                SqlParameter dn = new SqlParameter("dn", tr.DestinationName);
                SqlParameter t = new SqlParameter("t", tr.Title);
                fcmd.Parameters.Add(dn);
                fcmd.Parameters.Add(t);

                SqlDataReader feature = fcmd.ExecuteReader();
                //while (feature.Read())
                //{
                //    tr.KeyFeatures.Add(Convert.ToString(feature[0]));
                //}

                feature.Read();
                tr.KeyFeatures = Convert.ToString(feature[0]);

                feature.Close();

                string selectExS = "select service from ExcludedServices f join tour t on f.destinationName = @dn1 and f.title = @t1";
                SqlCommand es = new SqlCommand(selectExS, connection);
                SqlParameter dn1 = new SqlParameter("dn1", tr.DestinationName);
                SqlParameter t1 = new SqlParameter("t1", tr.Title);
                es.Parameters.Add(dn1);
                es.Parameters.Add(t1);

                SqlDataReader ExServices = es.ExecuteReader();
                //while (ExServices.Read())
                //{
                //    tr.ServicesExcluded.Add(Convert.ToString(ExServices[0]));
                //}

                ExServices.Read();
                tr.ExcludedServices = Convert.ToString(ExServices[0]);

                ExServices.Close();

                string selectS = "select service from IncludedServices f join tour t on f.destinationName = @dn2 and f.title = @t2";
                SqlCommand s = new SqlCommand(selectS, connection);
                SqlParameter dn2 = new SqlParameter("dn2", tr.DestinationName);
                SqlParameter t2 = new SqlParameter("t2", tr.Title);
                s.Parameters.Add(dn2);
                s.Parameters.Add(t2);

                SqlDataReader Services = s.ExecuteReader();
                //while (Services.Read())
                //{
                //    tr.ServicesIncluded.Add(Convert.ToString(Services[0]));
                //}


                Services.Read();
                tr.IncludedServices = Convert.ToString(Services[0]);

                Services.Close();


                connection.Close();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return tr;
        }

        public void Edit(Tour tour) 
        {
            Tour temp = find(tour.ID);   
            DeleteFeatures(temp);
            DeleteServicesExcluded(temp);
            DeleteServicesIncluded(temp);
            EditTour(tour);
            AddFeatures(tour);
            AddServicesExcluded(tour);
            AddServicesIncluded(tour);
        }
        //To be continueed....
        public void DeleteById(int id) { }
        //public Tour GetById(string id)
        //{

        //}
        public List<Tour> DisplayAllTours()
        {
            List<Tour> list = new List<Tour>();

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            //Insert into Tour
            string selectQuery = "select * from tour";


            SqlCommand cmd = new SqlCommand(selectQuery, connection);


            SqlDataReader tour = cmd.ExecuteReader();
            while (tour.Read())
            {
                Tour tr = new Tour();
                tr.DestinationName = Convert.ToString(tour[0]);
                tr.Title = Convert.ToString(tour[1]);
                tr.Description = Convert.ToString(tour[2]);
                tr.URL = Convert.ToString(tour[3]);
                tr.Ranking = Convert.ToInt32(tour[4]);
                tr.Cost = Convert.ToInt32(tour[5]);
                tr.StartTime = Convert.ToDateTime(tour[6]);
                tr.EndTime = Convert.ToDateTime(tour[7]);
                tr.ID = Convert.ToInt32(tour[8]);
                list.Add(tr);
            }

            tour.Close();

            foreach (Tour tr in list)
            {
                string selectFeatures = "select feature from keyFeatures f join tour t on f.destinationName = @dn and f.title = @t";
                SqlCommand fcmd = new SqlCommand(selectFeatures, connection);
                SqlParameter dn = new SqlParameter("dn", tr.DestinationName);
                SqlParameter t = new SqlParameter("t", tr.Title);
                fcmd.Parameters.Add(dn);
                fcmd.Parameters.Add(t);

                SqlDataReader feature = fcmd.ExecuteReader();
                //while (feature.Read())
                //{
                //    tr.KeyFeatures.Add(Convert.ToString(feature[0]));
                //}

                feature.Read();
                tr.KeyFeatures = Convert.ToString(feature[0]);
                feature.Close();

                string selectExS = "select service from ExcludedServices f join tour t on f.destinationName = @dn1 and f.title = @t1";
                SqlCommand es = new SqlCommand(selectExS, connection);
                SqlParameter dn1 = new SqlParameter("dn1", tr.DestinationName);
                SqlParameter t1 = new SqlParameter("t1", tr.Title);
                es.Parameters.Add(dn1);
                es.Parameters.Add(t1);

                SqlDataReader ExServices = es.ExecuteReader();
                //while (ExServices.Read())
                //{
                //    tr.ServicesExcluded.Add(Convert.ToString(ExServices[0]));
                //}

                ExServices.Read();
                tr.ExcludedServices = Convert.ToString(ExServices[0]);
                ExServices.Close();

                string selectS = "select service from ServicesIncluded f join tour t on f.destinationName = @dn2 and f.title = @t2";
                SqlCommand s = new SqlCommand(selectS, connection);
                SqlParameter dn2 = new SqlParameter("dn2", tr.DestinationName);
                SqlParameter t2 = new SqlParameter("t2", tr.Title);
                s.Parameters.Add(dn2);
                s.Parameters.Add(t2);

                SqlDataReader Services = s.ExecuteReader();
                //while (Services.Read())
                    //{
                    //    tr.ServicesIncluded.Add(Convert.ToString(Services[0]));
                    //}

                    Services.Read();
                tr.IncludedServices = Convert.ToString(Services[0]);

                Services.Close();

            }

            connection.Close();
            return list;
        }
    }
}
