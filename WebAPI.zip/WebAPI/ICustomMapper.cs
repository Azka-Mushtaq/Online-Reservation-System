﻿namespace WebAPI
{
    public interface ICustomMapper<TDomain, TWeb>
    {
        public Task<TDomain> WebToDomain(TWeb webEntity);
        public Task<TWeb> DomainToWeb(TDomain domainEntity);
        public Task<List<TWeb>> GetAll(List<TDomain> domainList);
    }
}