﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{

    public class UserController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult SignUp()
        {
            return View();
        }

    }
}
