﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Domain;
using Application;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using System.Collections.Generic;
using System;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TourController : ControllerBase
    {
        private readonly TourService _repository;
        private readonly ICustomMapper<Domain.Tour, WebAPI.Tour> _mapper;
        private readonly ILogger<TourController> _logger;
        private readonly IWebHostEnvironment _env;

        public TourController(ILogger<TourController> logger, IWebHostEnvironment env, TourService repository, ICustomMapper<Domain.Tour, WebAPI.Tour> mapper)
        {
            _logger = logger;
            _env = env;
            _repository = repository;
            _mapper = mapper;
        }

        // GET: api/Tour
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WebAPI.Tour>>> GetAllTours([FromQuery] string destinationName)
        {
            try
            {
                string columnNames = "ID,Title,DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                var tours = await _repository.GetAll(columnNames, "Tour", "destinationName", destinationName);
                var result = await _mapper.GetAll(tours);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving tours");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving data from the database");
            }
        }

        // GET: api/Tour/5
        [HttpGet("{id}")]
        public async Task<ActionResult<WebAPI.Tour>> GetTour(int id)
        {
            try
            {
                var tour = new WebAPI.Tour { ID = id };
                string columnNames = "Title,DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                tour = await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, "ID", "Tour", await _mapper.WebToDomain(tour)));

                if (tour == null) return NotFound();

                // Populate included, excluded services, and key features
                tour = await PopulateTourDetails(tour);
                return Ok(tour);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving the tour");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving data from the database");
            }
        }

        // POST: api/Tour
        [Authorize(Policy = "AdminOnly")]
        [HttpPost]
        public async Task<ActionResult<WebAPI.Tour>> CreateTour([FromForm] WebAPI.Tour tour, IFormFile url)
        {
            try
            {
                if (url != null && url.Length > 0)
                {
                    string wwwrootpath = _env.WebRootPath;
                    string path = Path.Combine(wwwrootpath, "UploadedImages/Tours");
                    string filepath = Path.Combine(path, url.FileName);
                    tour.URL = Path.Combine("UploadedImages/Tours", url.FileName);
                    using (var fileStream = new FileStream(filepath, FileMode.Create))
                    {
                        await url.CopyToAsync(fileStream);
                    }
                }

                if (ModelState.IsValid)
                {
                    string columnNames = "Title,DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                    await _repository.Add(columnNames, await _mapper.WebToDomain(tour), "Tour");

                    // Insert related data
                    await InsertTourDetails(tour);

                    return CreatedAtAction(nameof(GetTour), new { id = tour.ID }, tour);
                }

                return BadRequest(ModelState);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating a new tour");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error creating a new tour record");
            }
        }

        // PUT: api/Tour/5
        [Authorize(Policy = "AdminOnly")]
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateTour(int id, [FromBody] WebAPI.Tour tour)
        {
            if (id != tour.ID) return BadRequest("Tour ID mismatch");

            try
            {
                if (ModelState.IsValid)
                {
                    string title = tour.Title;
                    string columnNames = "DestinationName,Description,Cost,Ranking,EndTime,StartTime,URL";
                    await _repository.Update(columnNames, await _mapper.WebToDomain(tour), "Title", title, "Tour");

                    // Update related data
                    await UpdateTourDetails(tour, title);

                    return NoContent();
                }

                return BadRequest(ModelState);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating the tour");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error updating the tour record");
            }
        }

        // DELETE: api/Tour/5
        [Authorize(Policy = "AdminOnly")]
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteTour(string title)
        {
            try
            {
                await _repository.DeleteById("Title", title, "KeyFeatures");
                await _repository.DeleteById("Title", title, "ExcludedServices");
                await _repository.DeleteById("Title", title, "IncludedServices");
                await _repository.DeleteById("Title", title, "Tour");

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting the tour");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting the tour record");
            }
        }

        private async Task<WebAPI.Tour> PopulateTourDetails(WebAPI.Tour tour)
        {
            string columnNames = "IncludedServices";
            tour = await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, "DestinationName,Title", "IncludedServices", await _mapper.WebToDomain(tour)));

            columnNames = "ExcludedServices";
            tour = await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, "DestinationName,Title", "ExcludedServices", await _mapper.WebToDomain(tour)));

            columnNames = "KeyFeatures";
            tour = await _mapper.DomainToWeb(await _repository.FindByAttribute(columnNames, "DestinationName,Title", "KeyFeatures", await _mapper.WebToDomain(tour)));

            return tour;
        }

        private async Task InsertTourDetails(WebAPI.Tour tour)
        {
            string columnNames = "DestinationName,Title,IncludedServices";
            await _repository.Add(columnNames, await _mapper.WebToDomain(tour), "IncludedServices");

            columnNames = "DestinationName,Title,ExcludedServices";
            await _repository.Add(columnNames, await _mapper.WebToDomain(tour), "ExcludedServices");

            columnNames = "DestinationName,Title,KeyFeatures";
            await _repository.Add(columnNames, await _mapper.WebToDomain(tour), "KeyFeatures");
        }

        private async Task UpdateTourDetails(WebAPI.Tour tour, string title)
        {
            string columnNames = "DestinationName,IncludedServices";
            await _repository.Update(columnNames, await _mapper.WebToDomain(tour), "Title", title, "IncludedServices");

            columnNames = "DestinationName,ExcludedServices";
            await _repository.Update(columnNames, await _mapper.WebToDomain(tour), "Title", title, "ExcludedServices");

            columnNames = "DestinationName,KeyFeatures";
            await _repository.Update(columnNames, await _mapper.WebToDomain(tour), "Title", title, "KeyFeatures");
        }
    }
}
