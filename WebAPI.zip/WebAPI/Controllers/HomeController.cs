using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Domain;
using Application;
namespace WebAPI.Controllers
{

    public class HomeController : Controller
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";
        
        public async Task<IActionResult> Index()
        {
            /*string message = string.Empty;
            if (HttpContext.Request.Cookies.ContainsKey("first_visit"))
            {
                string? data = HttpContext.Request.Cookies["first_visit"];
                message = $"You Visited our website at {data}";

            }
            else
            {
                CookieOptions cookieOptions = new CookieOptions();
                cookieOptions.Expires = DateTime.Now.AddDays(1);
                HttpContext.Response.Cookies.Append("first_visit", DateTime.Now.ToString());
                message = "You visited First Time";
            }
            */
            Trace.WriteLine("Trace: Home Page");

            return View();
            //return View();

        }

        public async Task<IActionResult> ContactUs()
        {
            return View();
        }

        public async Task<IActionResult> About()
        {
            return View();
        }
    }
}
