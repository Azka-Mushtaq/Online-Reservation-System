﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.Common;

namespace WebAPI.Controllers
{
    // [Authorize(Policy = "AdminOnly")]
    public class AdminController : Controller
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=\"Online Reservation System\";Integrated Security=True;";


        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env;

        public AdminController(ILogger<HomeController> logger, IWebHostEnvironment env)
        {
            _logger = logger;
            _env = env;
        }
        public IActionResult Index()
        {
            return View();
        }


       
    }
}
