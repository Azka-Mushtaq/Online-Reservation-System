﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Domain;
using Application;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly BookingService _bookingService;
        private readonly ICustomMapper<Domain.Booking, WebAPI.Booking> _bookingMapper;

        public BookingController(BookingService bookingService, ICustomMapper<Domain.Booking, WebAPI.Booking> bookingMapper)
        {
            _bookingService = bookingService;
            _bookingMapper = bookingMapper;
        }

        // GET: api/Booking
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WebAPI.Booking>>> GetBookings()
        {
            var domainBookings = await _bookingService.GetAll();
            List<WebAPI.Booking> webBookings = new List<WebAPI.Booking>();
            if (domainBookings != null)
                webBookings = await _bookingMapper.GetAll(domainBookings);
            return Ok(webBookings);
        }

        // GET: api/Booking/5
        [HttpGet("{id}")]
        public async Task<ActionResult<WebAPI.Booking>> GetBooking(int id)
        {
            var domainBooking = await _bookingService.FindById(id);

            if (domainBooking == null)
            {
                return NotFound();
            }

            var webBooking = await _bookingMapper.DomainToWeb(domainBooking);
            return Ok(webBooking);
        }

        // POST: api/Booking
        [HttpPost]
        public async Task<ActionResult<WebAPI.Booking>> CreateBooking(WebAPI.Booking webBooking)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var domainBooking = await _bookingMapper.WebToDomain(webBooking);
            await _bookingService.Add(domainBooking);

            return Ok();
        }

   
        // DELETE: api/Booking/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBooking(int id)
        {
           await _bookingService.DeleteById(id,"Booking");

            return NoContent();
        }
    }
}
