﻿using Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DestinationController : ControllerBase
    {
        private readonly DestinationService _destinationService;
        private readonly ILogger<DestinationController> _logger;
        private readonly IWebHostEnvironment _env;
        private readonly IMemoryCache _memoryCache;
        private readonly CustomMapper<Domain.Destination, WebAPI.Destination> _mapper =
            new CustomMapper<Domain.Destination, WebAPI.Destination>();

        public DestinationController(
            ILogger<DestinationController> logger,
            IWebHostEnvironment env,
            DestinationService destinationService,
            IMemoryCache memoryCache)
        {
            _logger = logger;
            _env = env;
            _destinationService = destinationService;
            _memoryCache = memoryCache;
        }

        [HttpGet]
        [Route("getById{id}")]
        public async Task<IActionResult> GetDestinationById(int id)
        {
            try
            {
                var destination = await _destinationService.FindById(id);
                if (destination == null) return NotFound();
                var result = await _mapper.DomainToWeb(destination);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving destination by ID");
                return StatusCode(500, "Internal server error");
            }
        }

      
        [HttpGet]
        [Route("get")]

        public async Task<IActionResult> GetDestinations([FromQuery] string destinationType = "", [FromQuery] string destinationName = "")
        {
            try
            {
                List<WebAPI.Destination> data;
                if (!string.IsNullOrEmpty(destinationType))
                {
                    var cacheKey = destinationType;
                    if (!_memoryCache.TryGetValue(cacheKey, out data))
                    {
                        data = await _mapper.GetAll(await _destinationService.GetAll("DestinationType", destinationType));

                        var cacheEntryOptions = new MemoryCacheEntryOptions
                        {
                            AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(30)
                        };
                        _memoryCache.Set(cacheKey, data, cacheEntryOptions);
                    }
                }
                else
                {
                    data = await _mapper.GetAll(await _destinationService.GetAll("DestinationName", destinationName));
                }

                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving destinations");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Authorize(Policy = "AdminOnly")]
        [Route("add")]

        public async Task<IActionResult> AddDestination([FromForm] WebAPI.Destination destination)
        {
            try
            {
                if (destination.File != null && destination.File.Length > 0)
                {
                    string path = Path.Combine(_env.WebRootPath, "UploadedImages/Destinations", destination.File.FileName);
                    destination.URL = Path.Combine("UploadedImages/Destinations", destination.File.FileName);

                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await destination.File.CopyToAsync(stream);
                    }
                }

                await _destinationService.Add(await _mapper.WebToDomain(destination));
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding destination");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut]
        [Authorize(Policy = "AdminOnly")]
        [Route("update{id}")]

        public async Task<IActionResult> EditDestination(int id, [FromForm] WebAPI.Destination destination)
        {
            try
            {
                if (id != destination.ID) return BadRequest("Destination ID mismatch");

                if (destination.File != null && destination.File.Length > 0)
                {
                    string path = Path.Combine(_env.WebRootPath, "UploadedImages/Destinations", destination.File.FileName);
                    destination.URL = Path.Combine("UploadedImages/Destinations", destination.File.FileName);

                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await destination.File.CopyToAsync(stream);
                    }
                }

                var domainDestination = await _mapper.WebToDomain(destination);
                await _destinationService.Update(domainDestination);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error editing destination");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete]
        [Route("delete{name}")]

        [Authorize(Policy = "AdminOnly")]
        public async Task<IActionResult> DeleteDestination(string name)
        {
            try
            {
                await _destinationService.DeleteById("DestinationName", name, "Destination");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting destination");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
